import random
import timeit

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Example usage:
x = 9
result = sum_of_natural_numbers(x)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first {x} natural numbers is {result}")

# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Example usage:
count = 9
result = fibonacci(count)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The {count}th Fibonacci number is {result}")

# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Example usage:
num = 7
result = factorial(num)
print(f"The factorial of {num} is {result}")


sum_time = timeit.timeit(lambda: sum_of_natural_numbers(x))
fibonacci_time = timeit.timeit(lambda: fibonacci(count))
factorial_time = timeit.timeit(lambda: factorial(num))

print(f"Sum numbers took: {sum_time:.6f} seconds")
print(f"fibonacci took: {fibonacci_time:.6f} seconds")
print(f"factorial took: {factorial_time:.6f} seconds")
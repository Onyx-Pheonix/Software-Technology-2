from collections import deque

class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
    def preorder(self, root):
        if root:
            print(root.value, end=' ')
            self.preorder(root.left)
            self.preorder(root.right)
    def inorder(self, root):
        if root:
            self.inorder(root.left)
            print(root.value, end=' ')
            self.inorder(root.right)
    def postorder(self, root):
        if root:
            self.postorder(root.left)
            self.postorder(root.right)
            print(root.value, end=' ')
    def count_nodes(self, root):
        if root is None:
            return 0
        return 1 + self.count_nodes(root.left) + self.count_nodes(root.right)
    def height(self, root):
        if root is None:
            return 0
        return 1 + max(self.height(root.left), self.height(root.right))
    def search_bst(self, root, val):
        if root is None or root.value == val:
            return root
        if val < root.value:
            return self.search_bst(root.left, val)
        else:
            return self.search_bst(root.right, val)
    def insert_bst(self, root, val):
        if root is None:
            return Node(val)
        if val < root.value:
            root.left = self.insert_bst(root.left, val)
        else:
            root.right = self.insert_bst(root.right, val)
        return root
    def find_min(root):
        current = root
        while current.left:
            current = current.left
        return current
    def delete_node(self, root, val):
        if root is None:
            return root
        if val < root.value:
            root.left = self.delete_node(root.left, val)
        elif val > root.value:
            root.right = self.delete_node(root.right, val)
        else:
            # Node with 1 or no child
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            # Node with two children
            temp = self.find_min(root.right)
            root.value = temp.value
            root.right = self.delete_node(root.right, temp.value)
        return root
    def level_order(root):
        if not root:
            return
        queue = deque([root])
        while queue:
            node = queue.popleft()
            print(node.value, end=' ')
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)


# Example: create root node
root = Node(10)
root.left = Node(5)
root.right = Node(15)
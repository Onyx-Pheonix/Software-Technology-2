from collections import deque

class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
        else:
            print("One or both vertices not found in graph.")


    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]  # Add a new vertex with an empty list of edges
    
    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].remove(vertex2)
            if self.weighted:
                del self.weights[(vertex1, vertex2)]
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].remove(vertex1)
                if self.weighted:
                    del self.weights[(vertex2, vertex1)]
        else:
            print("One or both vertices not found in graph.")
    
    def print_graph(self):
        for vertex, edges in self.graph.items():
            if self.weighted:
                edge_info = []
                for edge in edges:
                    weight = self.weights.get((vertex, edge))
                    edge_info.append(f"{edge} (Weight: {weight})")
                print(f"{vertex}: {', '.join(edge_info)}")
            else:
                print(f"{vertex}: {', '.join(edges)}")
    
    def bfs(self, s):
        visited = []
        queue = deque([s])

        while queue:
            node = queue.popleft()
            if node not in visited:
                visited.append(node)
                print(node, end=" ")
            
                for neighbor in self.graph[node]:
                    if neighbor not in visited:
                        queue.append(neighbor)
    
    def dfs(self, start):
        visted = []
        stack = [start]

        while stack:
            node = stack.pop()
            if node not in visted:
                visted.append(node)
                print(node, end=" ")
                stack.extend(reversed(self.graph[node]))
    
    def cycle_check(self, edge, parent):
        visted = []
        stack = [edge]

        while stack:
            node = stack.pop()
            if node in visted:
                if node != parent:
                    return True
            elif node not in visted:
                visted.append(node)
                stack.extend(reversed(self.graph[node]))
        return False    

    def has_undirected_cycle(self):
        visted = []
        for vertex, edges in self.graph.items():
            for vertex in self.graph:
                if vertex not in visted:
                    visted.append(vertex)
                    for edge in edges:
                        if self.cycle_check(edge, vertex):
                            return True
        return False



            
